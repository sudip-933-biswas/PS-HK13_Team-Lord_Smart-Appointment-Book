from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(100))
    role = db.Column(db.String(20), default="admin")  # admin, superadmin
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "full_name": self.full_name,
            "role": self.role,
            "created_at": self.created_at.strftime("%Y-%m-%d %H:%M") if self.created_at else None,
            "last_login": self.last_login.strftime("%Y-%m-%d %H:%M") if self.last_login else None,
        }


class Department(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    avg_consultation_minutes = db.Column(db.Float, default=15.0)
    doctors = db.relationship("Doctor", backref="dept", lazy=True)
    queue_entries = db.relationship("QueueEntry", backref="dept", lazy=True)
    appointments = db.relationship("Appointment", backref="dept", lazy=True)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "avg_consultation_minutes": self.avg_consultation_minutes,
        }


class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    specialty = db.Column(db.String(100))
    qualification = db.Column(db.String(200))  # e.g., MBBS, MD, BDS
    department_id = db.Column(db.Integer, db.ForeignKey("department.id"), nullable=False)
    status = db.Column(db.String(20), default="available")  # available, busy, break, offline
    current_patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=True)
    consultation_start = db.Column(db.DateTime, nullable=True)
    patients_seen_today = db.Column(db.Integer, default=0)
    total_minutes_today = db.Column(db.Float, default=0.0)
    # appointments relationship removed to avoid conflict - defined in Appointment model
    department = db.relationship("Department", backref="dept")

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "specialty": self.specialty,
            "qualification": self.qualification,
            "department": self.department.name if self.department else None,
            "department_id": self.department_id,
            "status": self.status,
            "current_patient_id": self.current_patient_id,
            "patients_seen_today": self.patients_seen_today,
            "total_minutes_today": self.total_minutes_today,
        }


class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer)
    gender = db.Column(db.String(10))
    condition = db.Column(db.String(200))
    priority_score = db.Column(db.Float, default=0.5)  # 0-1, higher = more urgent
    arrival_time = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="waiting")  # registered, waiting, in-consultation, completed, no-show
    is_walk_in = db.Column(db.Boolean, default=False)
    is_emergency = db.Column(db.Boolean, default=False)
    # appointments relationship removed to avoid conflict - defined in Appointment model
    # queue_entries relationship removed to avoid conflict - defined in QueueEntry model

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "age": self.age,
            "gender": self.gender,
            "condition": self.condition,
            "priority_score": round(self.priority_score, 2),
            "arrival_time": self.arrival_time.strftime("%H:%M") if self.arrival_time else None,
            "status": self.status,
            "is_walk_in": self.is_walk_in,
            "is_emergency": self.is_emergency,
        }


class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey("doctor.id"), nullable=False)
    department_id = db.Column(db.Integer, db.ForeignKey("department.id"), nullable=False)
    scheduled_time = db.Column(db.DateTime, nullable=False)
    predicted_duration = db.Column(db.Float)  # minutes
    actual_duration = db.Column(db.Float, nullable=True)
    status = db.Column(db.String(20), default="scheduled")  # scheduled, in-progress, completed, cancelled, no-show
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    delay_minutes = db.Column(db.Float, default=0.0)
    
    # Relationships - direct relationships without backrefs to avoid conflicts
    patient = db.relationship("Patient")
    doctor = db.relationship("Doctor") 
    department = db.relationship("Department")

    def to_dict(self):
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "patient_name": self.patient.name if self.patient else None,
            "doctor_id": self.doctor_id,
            "doctor_name": self.doctor.name if self.doctor else None,
            "department_id": self.department_id,
            "department_name": self.department.name if self.department else None,
            "scheduled_time": self.scheduled_time.strftime("%H:%M") if self.scheduled_time else None,
            "predicted_duration": self.predicted_duration,
            "actual_duration": self.actual_duration,
            "status": self.status,
            "delay_minutes": self.delay_minutes,
        }


class QueueEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=False)
    department_id = db.Column(db.Integer, db.ForeignKey("department.id"), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey("doctor.id"), nullable=True)  # Added doctor_id field
    position = db.Column(db.Integer)
    estimated_wait_minutes = db.Column(db.Float, default=0.0)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="waiting")  # waiting, called, served, in-consultation
    
    # Relationships
    patient = db.relationship("Patient")
    department = db.relationship("Department")
    doctor = db.relationship("Doctor")

    def to_dict(self):
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "patient_name": self.patient.name if self.patient else None,
            "patient_priority": self.patient.priority_score if self.patient else 0,
            "patient_emergency": self.patient.is_emergency if self.patient else False,
            "department_id": self.department_id,
            "department_name": self.department.name if self.department else None,
            "position": self.position,
            "estimated_wait_minutes": round(self.estimated_wait_minutes, 1),
            "joined_at": self.joined_at.strftime("%H:%M") if self.joined_at else None,
            "status": self.status,
        }


class OptimizationLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    action_type = db.Column(db.String(50))  # reassign, priority_boost, slot_fill, emergency_insert
    description = db.Column(db.Text)
    reason = db.Column(db.Text)  # explainability
    confidence = db.Column(db.Float)
    impact_score = db.Column(db.Float)  # estimated time saved in minutes
    applied = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "action_type": self.action_type,
            "description": self.description,
            "reason": self.reason,
            "confidence": round(self.confidence, 2) if self.confidence else None,
            "impact_score": round(self.impact_score, 1) if self.impact_score else None,
            "applied": self.applied,
            "created_at": self.created_at.strftime("%Y-%m-%d %H:%M") if self.created_at else None,
        }
