"""
PatientFlow AI - Real-Time Patient Queue & Appointment Optimization Platform
Main Flask Application
"""
import os
import sys
from functools import wraps
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from models import db, Admin, Department, Doctor, Patient, Appointment, QueueEntry, OptimizationLog
from predictor import PatientPredictor
from optimizer import QueueOptimizer
from explainer import ScheduleExplainer

# ── App Setup ──────────────────────────────────────────────────────────────
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///patientflow.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = "patientflow-ai-secret-key"

db.init_app(app)

predictor = PatientPredictor()
optimizer = QueueOptimizer()
explainer = ScheduleExplainer()


# ── Auth Helpers ───────────────────────────────────────────────────────────

def login_required(f):
    """Decorator to require admin login for protected routes."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "admin_id" not in session:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for("login", next=request.url))
        return f(*args, **kwargs)
    return decorated_function


@app.context_processor
def inject_admin():
    """Make current admin available in all templates."""
    admin = None
    if "admin_id" in session:
        admin = Admin.query.get(session["admin_id"])
    return dict(current_admin=admin)


# ── Auth Routes ────────────────────────────────────────────────────────────

@app.route("/login", methods=["GET", "POST"])
def login():
    """Admin login page."""
    if "admin_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        admin = Admin.query.filter_by(username=username).first()
        if admin and admin.check_password(password):
            session["admin_id"] = admin.id
            session["admin_name"] = admin.full_name or admin.username
            admin.last_login = datetime.utcnow()
            db.session.commit()
            flash(f"Welcome back, {session['admin_name']}!", "success")
            next_page = request.args.get("next")
            return redirect(next_page or url_for("dashboard"))
        else:
            flash("Invalid username or password.", "danger")

    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Admin registration page."""
    if "admin_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        # Validation
        errors = []
        if not username or len(username) < 3:
            errors.append("Username must be at least 3 characters.")
        if not email or "@" not in email:
            errors.append("Please enter a valid email address.")
        if not password or len(password) < 6:
            errors.append("Password must be at least 6 characters.")
        if password != confirm_password:
            errors.append("Passwords do not match.")
        if Admin.query.filter_by(username=username).first():
            errors.append("Username already taken.")
        if Admin.query.filter_by(email=email).first():
            errors.append("Email already registered.")

        if errors:
            for error in errors:
                flash(error, "danger")
            return render_template("register.html")

        admin = Admin(
            username=username,
            email=email,
            full_name=full_name or username,
        )
        admin.set_password(password)
        db.session.add(admin)
        db.session.commit()

        flash("Account created successfully! Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/logout")
def logout():
    """Log out current admin."""
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# ── Public User Routes (No Login Required) ─────────────────────────────────

@app.route("/")
def index():
    """Home page - always redirect to booking page for all users."""
    return redirect(url_for("book_appointment"))


@app.route("/book")
def book_appointment():
    """Public appointment booking page for patients."""
    departments = Department.query.all()
    return render_template("book_appointment.html", 
        departments=[d.to_dict() for d in departments])


@app.route("/book/submit", methods=["POST"])
def submit_booking():
    """Submit a new appointment booking."""
    try:
        # Get form data
        name = request.form.get("patient_name", "").strip()
        phone = request.form.get("phone", "").strip()
        age = request.form.get("age", "").strip()
        age_type = request.form.get("age_type", "years")
        gender = request.form.get("gender", "")
        condition = request.form.get("condition", "").strip()
        department_id = request.form.get("department_id", "")
        doctor_id = request.form.get("doctor_id", "")
        preferred_date = request.form.get("preferred_date", "")
        preferred_time = request.form.get("preferred_time", "")
        
        # Enhanced validation
        import re
        
        # Name validation - only letters and spaces, minimum 2 characters
        if not name:
            return jsonify({"success": False, "message": "Name is required."}), 400
        if not re.match(r'^[A-Za-z\s]{2,}$', name):
            return jsonify({"success": False, "message": "Name should contain only letters and spaces (minimum 2 characters)."}), 400
        
        # Condition validation
        if not condition:
            return jsonify({"success": False, "message": "Condition is required."}), 400
        
        # Phone validation - Indian mobile number format
        if not phone:
            return jsonify({"success": False, "message": "Phone number is required."}), 400
        # Remove any non-digit characters first
        phone_digits = re.sub(r'\D', '', phone)
        if not re.match(r'^[6-9][0-9]{9}$', phone_digits):
            return jsonify({"success": False, "message": "Please enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9."}), 400
        
        # Age validation
        age_value = None
        if age:
            try:
                age_num = int(age)
                if age_type == "months":
                    if not (1 <= age_num <= 11):
                        return jsonify({"success": False, "message": "Age should be between 1-11 months."}), 400
                    # Convert months to years for storage (as fraction)
                    age_value = age_num / 12
                else:
                    if not (1 <= age_num <= 100):
                        return jsonify({"success": False, "message": "Age must be between 1 and 100 years."}), 400
                    age_value = age_num
            except ValueError:
                return jsonify({"success": False, "message": "Please enter a valid age."}), 400
        
        if not department_id or not doctor_id:
            return jsonify({"success": False, "message": "Department and doctor selection are required."}), 400
        
        # Check if patient already exists
        existing_patient = Patient.query.filter_by(
            name=name,
            age=age_value,
            gender=gender,
            condition=condition
        ).first()
        
        if existing_patient:
            patient = existing_patient
            # Update arrival time for existing patient
            patient.arrival_time = datetime.utcnow()
            patient.priority_score = predictor.compute_priority_score(patient)
        else:
            # Create new patient record
            patient = Patient(
                name=name,
                age=age_value,
                gender=gender,
                condition=condition,
                status="registered",
                is_walk_in=False,
                arrival_time=datetime.utcnow(),
            )
            patient.priority_score = predictor.compute_priority_score(patient)
            db.session.add(patient)
        
        db.session.flush()  # Get patient id without committing
        
        # Create appointment
        scheduled_time_str = f"{preferred_date} {preferred_time}"
        scheduled_time = datetime.strptime(scheduled_time_str, "%Y-%m-%d %H:%M")
        
        doctor = Doctor.query.get(int(doctor_id))
        department = Department.query.get(int(department_id))
        
        if not doctor or not department:
            return jsonify({"success": False, "message": "Invalid doctor or department."}), 400
        
        # Check if selected doctor is available and not busy
        is_doctor_available = False
        if doctor.status == "available":
            # Check if doctor is currently busy with another patient
            current_consultation = QueueEntry.query.filter_by(
                doctor_id=doctor.id, 
                status="in-consultation"
            ).first()
            
            if not current_consultation:
                # Check if doctor has any active appointments
                active_appointment = Appointment.query.filter_by(
                    doctor_id=doctor.id, 
                    status="in-progress"
                ).first()
                
                if not active_appointment:
                    is_doctor_available = True
        
        predicted_duration = predictor.predict_consultation_duration(patient, department)
        
        # Set patient status based on doctor availability
        if is_doctor_available:
            patient.status = "in-consultation"
            # Update doctor status to busy
            doctor.status = "busy"
            doctor.current_patient_id = patient.id
            doctor.consultation_start = datetime.utcnow()
        else:
            patient.status = "registered"  # Will be updated to "waiting" when they arrive
        
        appointment = Appointment(
            patient_id=patient.id,
            doctor_id=doctor.id,
            department_id=department.id,
            scheduled_time=scheduled_time,
            predicted_duration=predicted_duration,
            status="scheduled",
        )
        db.session.add(appointment)
        db.session.commit()
        
        # Create queue entry if doctor is available for immediate consultation
        if is_doctor_available:
            queue_entry = QueueEntry(
                patient_id=patient.id,
                department_id=department.id,
                doctor_id=doctor.id,
                position=0,  # No queue position for immediate consultation
                estimated_wait_minutes=0,  # No wait time
                joined_at=datetime.utcnow(),
                status="in-consultation"
            )
            db.session.add(queue_entry)
            db.session.commit()
            
            success_message = f"Appointment booked successfully! You are now in consultation with Dr. {doctor.name}."
        else:
            success_message = f"Appointment booked successfully! Your appointment is scheduled with Dr. {doctor.name} on {preferred_date} at {preferred_time}."
        
        return jsonify({
            "success": True,
            "message": success_message,
            "appointment_id": appointment.id,
            "immediate_consultation": is_doctor_available,
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": f"Error booking appointment: {str(e)}"}), 500


# ── Helper Functions ───────────────────────────────────────────────────────
def get_dashboard_stats():
    """Compute dashboard KPI stats."""
    queue_entries = QueueEntry.query.filter_by(status="waiting").all()
    doctors = Doctor.query.filter(Doctor.status != "offline").all()
    departments = Department.query.all()

    total_waiting = len(queue_entries)
    avg_wait = round(sum(q.estimated_wait_minutes for q in queue_entries) / max(total_waiting, 1), 1)
    active_doctors = len([d for d in doctors if d.status in ("available", "busy")])
    bottlenecks = predictor.predict_bottlenecks(departments, queue_entries, doctors)

    return {
        "total_waiting": total_waiting,
        "avg_wait_time": avg_wait,
        "active_doctors": active_doctors,
        "bottleneck_count": len(bottlenecks),
    }, bottlenecks


@app.route("/api/doctor/<int:doctor_id>/status", methods=["POST"])
@login_required
def update_doctor_status(doctor_id):
    """API endpoint to update doctor status."""
    try:
        data = request.get_json()
        new_status = data.get('status')
        
        if new_status not in ['available', 'busy', 'offline']:
            return jsonify({'success': False, 'message': 'Invalid status'})
        
        doctor = Doctor.query.get_or_404(doctor_id)
        old_status = doctor.status
        doctor.status = new_status
        
        # If setting to available, clear current patient and consultation time
        if new_status == 'available':
            doctor.current_patient_id = None
            doctor.consultation_start = None
        
        # If setting to busy, require a current patient
        elif new_status == 'busy' and not doctor.current_patient_id:
            return jsonify({'success': False, 'message': 'Cannot set doctor to busy without assigned patient'})
        
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': f'Doctor status updated from {old_status} to {new_status}'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})


# ── Page Routes ────────────────────────────────────────────────────────────

@app.route("/dashboard")
@login_required
def dashboard():
    """Main dashboard with real-time queue status, charts, and AI insights."""
    stats, bottlenecks = get_dashboard_stats()

    queue_entries = QueueEntry.query.filter_by(status="waiting").all()
    queue_data = sorted(
        [q.to_dict() for q in queue_entries],
        key=lambda x: (
            -1 if x.get("patient_emergency", False) else  # Emergency patients first (priority -1)
            -x["patient_priority"],  # Then by priority score
            x["joined_at"]  # Then by join time
        ),
    )
    
    # Assign global queue positions
    for i, q in enumerate(queue_data, 1):
        q["global_position"] = i

    # Doctor utilization data for chart
    doctors = Doctor.query.filter(Doctor.status != "offline").all()
    doctor_utilization = []
    
    for doctor in doctors:
        # Calculate doctor statistics
        patients_today = QueueEntry.query.filter_by(doctor_id=doctor.id).filter(
            QueueEntry.joined_at >= datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        ).count()
        
        # Calculate utilization based on current status and consultation time
        utilization = 0
        if doctor.status == "busy" and doctor.consultation_start:
            # Simple utilization calculation based on consultation time
            minutes_in_consultation = (datetime.now() - doctor.consultation_start).seconds // 60
            utilization = min(100, (minutes_in_consultation / 15) * 100)  # Assuming 15 min avg consultation
        
        doctor_dict = doctor.to_dict()
        # Add department name separately to ensure it's available
        if doctor.department:
            doctor_dict['department_name'] = doctor.department.name
        else:
            doctor_dict['department_name'] = 'Unassigned'
            
        doctor_dict.update({
            'patients_seen_today': patients_today,
            'utilization': utilization,
            'current_patient': Patient.query.get(doctor.current_patient_id).to_dict() if doctor.current_patient_id else None
        })
        doctor_utilization.append(doctor_dict)

    # Department queue data for chart
    departments = Department.query.all()
    dept_queue_data = []
    for dept in departments:
        dept_q = QueueEntry.query.filter_by(department_id=dept.id, status="waiting").count()
        dept_docs = Doctor.query.filter_by(department_id=dept.id).filter(Doctor.status != "offline").count()
        dept_queue_data.append({
            "name": dept.name,
            "queue_count": dept_q,
            "doctor_count": dept_docs,
            "avg_time": dept.avg_consultation_minutes,
        })

    # AI Insights
    logs = OptimizationLog.query.all()
    insights = explainer.generate_dashboard_insights(bottlenecks, logs)

    return render_template("dashboard.html",
        stats=stats,
        bottlenecks=bottlenecks,
        queue_entries=queue_data,
        doctor_utilization=doctor_utilization,
        dept_queue_data=dept_queue_data,
        insights=insights,
        doctors=doctors,  # Add doctors list for the doctor dashboard
        now=datetime.now(),  # Add current time for consultation duration calculation
    )


@app.route("/patients")
@login_required
def patients():
    """Patient management page - show all patients but only allow actions for current doctor's patients."""
    status_filter = request.args.get("status")
    if status_filter:
        patient_list = Patient.query.filter_by(status=status_filter).all()
    else:
        # Include all patients so newly booked appointments can be checked in
        patient_list = Patient.query.all()

    # Sort patients: Emergency patients first, then by ID for sequential order
    sorted_patients = sorted(patient_list, key=lambda p: (
        -1 if p.is_emergency else 0,  # Emergency patients first
        p.id  # Then by ID for sequential order
    ))

    # Get all doctors for display
    doctors = Doctor.query.filter(Doctor.status != "offline").all()
    
    departments = Department.query.all()
    return render_template("patients.html",
        patients=[p.to_dict() for p in sorted_patients],
        doctors=[d.to_dict() for d in doctors],
        departments=[d.to_dict() for d in departments],
        status_filter=status_filter,
    )


@app.route("/patients/<int:patient_id>/start-consultation", methods=["POST"])
@login_required
def start_consultation(patient_id):
    """Start consultation for a waiting patient - only one per doctor at a time."""
    try:
        patient = Patient.query.get_or_404(patient_id)
        
        if patient.status != "waiting":
            flash("Patient is not in waiting status", "danger")
            return redirect(url_for("patients"))
        
        # Find available doctor in the patient's department (if any queue entry exists)
        queue_entry = QueueEntry.query.filter_by(patient_id=patient_id, status="waiting").first()
        
        if queue_entry:
            department = queue_entry.department
            # Find available doctor in the department
            available_doctor = Doctor.query.filter_by(
                department_id=department.id, 
                status="available"
            ).first()
            
            if not available_doctor:
                # If no available doctor, find any doctor in the department and set them to busy
                available_doctor = Doctor.query.filter_by(
                    department_id=department.id
                ).filter(Doctor.status != "offline").first()
                
                if available_doctor:
                    available_doctor.status = "busy"
        else:
            # If no queue entry, find any available doctor
            available_doctor = Doctor.query.filter_by(status="available").first()
            
            if not available_doctor:
                flash("No doctors available for consultation", "warning")
                return redirect(url_for("patients"))
        
        if available_doctor:
            # Update patient status
            patient.status = "in-consultation"
            
            # Assign to doctor
            available_doctor.current_patient_id = patient.id
            available_doctor.consultation_start = datetime.utcnow()
            if available_doctor.status == "available":
                available_doctor.status = "busy"
            
            # Remove from queue if exists
            if queue_entry:
                queue_entry.status = "served"
            
            flash(f"Consultation started for {patient.name} with Dr. {available_doctor.name}", "success")
        else:
            flash("No doctors available for consultation", "warning")
        
        db.session.commit()
        return redirect(url_for("patients"))
        
    except Exception as e:
        db.session.rollback()
        flash(f"Error starting consultation: {str(e)}", "danger")
        return redirect(url_for("patients"))


@app.route("/patients/<int:patient_id>/complete-consultation", methods=["POST"])
@login_required
def complete_consultation(patient_id):
    """Complete consultation and auto-transfer next waiting patient."""
    try:
        # Get current patient in consultation
        current_patient = Patient.query.get_or_404(patient_id)
        
        # Get the doctor who was consulting this patient
        doctor = Doctor.query.filter_by(current_patient_id=patient_id).first()
        
        if not doctor:
            flash("No doctor found for this patient", "danger")
            return redirect(url_for("patients"))
        
        # Mark current patient as completed
        current_patient.status = "completed"
        
        # Clear doctor's current patient
        doctor.current_patient_id = None
        doctor.consultation_start = None
        
        # Find next waiting patient for the same doctor's department based on priority
        next_queue_entry = QueueEntry.query.filter_by(
            department_id=doctor.department_id, 
            status="waiting"
        ).join(Patient).order_by(
            Patient.is_emergency.desc(),
            Patient.priority_score.desc(),
            QueueEntry.position.asc()
        ).first()
        
        if next_queue_entry:
            # Get the next patient
            next_patient = next_queue_entry.patient
            
            # Update next patient status to in-consultation
            next_patient.status = "in-consultation"
            
            # Assign to doctor
            doctor.current_patient_id = next_patient.id
            doctor.consultation_start = datetime.utcnow()
            
            # Remove from queue
            next_queue_entry.status = "served"
            
            flash(f"Consultation completed. {next_patient.name} automatically transferred to consultation.", "success")
        else:
            flash(f"Consultation completed. No patients waiting in {doctor.department.name}.", "info")
        
        db.session.commit()
        return redirect(url_for("patients"))
        
    except Exception as e:
        db.session.rollback()
        flash(f"Error completing consultation: {str(e)}", "danger")
        return redirect(url_for("patients"))


@app.route("/patients/add", methods=["POST"])
@login_required
def add_patient():
    """Register a new patient."""
    patient = Patient(
        name=request.form["name"],
        age=int(request.form["age"]),
        gender=request.form["gender"],
        condition=request.form["condition"],
        is_walk_in="is_walk_in" in request.form,
        is_emergency="is_emergency" in request.form,
        arrival_time=datetime.utcnow(),
        status="registered",
    )
    patient.priority_score = predictor.compute_priority_score(patient)
    db.session.add(patient)
    db.session.commit()

    flash(f"Patient {patient.name} registered. Priority score: {patient.priority_score:.2f}", "success")
    return redirect(url_for("patients"))


@app.route("/patients/<int:patient_id>/check-in", methods=["POST"])
@login_required
def check_in_patient(patient_id):
    """Check in a patient and add to queue."""
    try:
        patient = Patient.query.get_or_404(patient_id)
        
        # Determine department from patient's appointment or use default
        appointment = Appointment.query.filter_by(patient_id=patient_id, status="scheduled").first()
        if appointment:
            department = appointment.department
        else:
            # Use first department as default
            department = Department.query.first()

        # Check for available and not busy doctors
        available_doctor = None
        doctors = Doctor.query.filter_by(department_id=department.id).filter(
            Doctor.status == "available"
        ).all()
        
        for doctor in doctors:
            # Check if doctor is currently busy with another patient
            current_consultation = QueueEntry.query.filter_by(
                doctor_id=doctor.id, 
                status="in-consultation"
            ).first()
            
            if not current_consultation:
                # Check if doctor has any active appointments
                active_appointment = Appointment.query.filter_by(
                    doctor_id=doctor.id, 
                    status="in-progress"
                ).first()
                
                if not active_appointment:
                    available_doctor = doctor
                    break
        
        if available_doctor:
            # Direct consultation - set status to "in-consultation" and assign doctor
            patient.status = "in-consultation"
            patient.priority_score = predictor.compute_priority_score(patient)
            
            # Update doctor status to busy
            available_doctor.status = "busy"
            available_doctor.current_patient_id = patient.id
            available_doctor.consultation_start = datetime.utcnow()
            
            # Create queue entry with in-consultation status
            entry = QueueEntry(
                patient_id=patient.id,
                department_id=department.id,
                doctor_id=available_doctor.id,
                position=0,  # No queue position for direct consultation
                estimated_wait_minutes=0,  # No wait time
                joined_at=datetime.utcnow(),
                status="in-consultation"
            )
            db.session.add(entry)
            
            # Update appointment status if exists
            if appointment:
                appointment.status = "in-progress"
                appointment.actual_duration = 0  # Will be updated when consultation ends
            
            db.session.commit()
            
            flash(f"{patient.name} is now in consultation with Dr. {available_doctor.name}", "success")
            
        else:
            # Regular queue - set status to "waiting"
            patient.status = "waiting"
            patient.priority_score = predictor.compute_priority_score(patient)

            # Find queue position
            current_queue = QueueEntry.query.filter_by(
                department_id=department.id, status="waiting"
            ).count()

            doctors = Doctor.query.filter_by(department_id=department.id).filter(
                Doctor.status != "offline"
            ).all()
            queue_entries = QueueEntry.query.filter_by(
                department_id=department.id, status="waiting"
            ).all()

            wait_time = predictor.predict_wait_time(queue_entries, department, doctors)

            entry = QueueEntry(
                patient_id=patient.id,
                department_id=department.id,
                position=current_queue + 1,
                estimated_wait_minutes=wait_time,
                joined_at=datetime.utcnow(),
            )
            db.session.add(entry)
            db.session.commit()

            print(f"After check-in - Patient {patient.name} status: {patient.status}")
            flash(f"{patient.name} checked in. Queue position: #{current_queue + 1}, Est. wait: {wait_time:.0f} min", "success")
        
        return redirect(url_for("patients"))
        
    except Exception as e:
        db.session.rollback()
        print(f"Error during check-in: {str(e)}")
        flash(f"Error during check-in: {str(e)}", "danger")
        return redirect(url_for("patients"))


@app.route("/patients/<int:patient_id>/no-show", methods=["POST"])
@login_required
def mark_no_show(patient_id):
    """Mark a patient as no-show."""
    patient = Patient.query.get_or_404(patient_id)
    patient.status = "no-show"

    # Remove from queue
    QueueEntry.query.filter_by(patient_id=patient_id, status="waiting").update({"status": "served"})

    # Cancel appointments
    Appointment.query.filter_by(patient_id=patient_id, status="scheduled").update({"status": "no-show"})

    db.session.commit()
    flash(f"{patient.name} marked as no-show.", "warning")
    return redirect(url_for("patients"))


@app.route("/patients/<int:patient_id>/delete", methods=["POST"])
@login_required
def delete_patient(patient_id):
    """Delete a patient and all associated records."""
    try:
        patient = Patient.query.get_or_404(patient_id)
        
        # Delete associated records
        # Delete queue entries
        QueueEntry.query.filter_by(patient_id=patient_id).delete()
        
        # Delete appointments
        Appointment.query.filter_by(patient_id=patient_id).delete()
        
        # If patient is in consultation, free up the doctor
        if patient.status == "in-consultation":
            # Find the doctor who is currently consulting this patient
            queue_entry = QueueEntry.query.filter_by(
                patient_id=patient_id, 
                status="in-consultation"
            ).first()
            
            if queue_entry and queue_entry.doctor_id:
                doctor = Doctor.query.get(queue_entry.doctor_id)
                if doctor:
                    doctor.status = "available"
                    doctor.current_patient_id = None
                    doctor.consultation_start = None
        
        # Delete the patient
        db.session.delete(patient)
        db.session.commit()
        
        flash(f"Patient {patient.name} has been deleted successfully.", "success")
        return redirect(url_for("patients"))
        
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting patient: {str(e)}", "danger")
        return redirect(url_for("patients"))


@app.route("/appointments")
@login_required
def appointments():
    """Appointments page with AI-predicted durations and delay probabilities."""
    appt_list = Appointment.query.all()
    appointments_data = [a.to_dict() for a in appt_list]

    # Compute delay probabilities
    delay_probs = {}
    for appt in appt_list:
        doctor = Doctor.query.get(appt.doctor_id)
        if doctor:
            delay_probs[appt.id] = predictor.predict_delay_probability(appt, doctor)

    # Stats
    stats = {
        "total": len(appt_list),
        "completed": len([a for a in appt_list if a.status == "completed"]),
        "in_progress": len([a for a in appt_list if a.status == "in-progress"]),
        "delayed": len([a for a in appt_list if a.delay_minutes and a.delay_minutes > 5]),
    }

    departments = Department.query.all()
    doctors = Doctor.query.all()
    all_patients = Patient.query.all()

    return render_template("appointments.html",
        appointments=appointments_data,
        delay_probs=delay_probs,
        stats=stats,
        departments=[d.to_dict() for d in departments],
        doctors=[d.to_dict() for d in doctors],
        all_patients=[p.to_dict() for p in all_patients],
    )


@app.route("/appointments/schedule", methods=["POST"])
@login_required
def schedule_appointment():
    """Schedule a new appointment with AI-predicted duration."""
    patient = Patient.query.get(int(request.form["patient_id"]))
    department = Department.query.get(int(request.form["department_id"]))
    doctor = Doctor.query.get(int(request.form["doctor_id"]))

    scheduled_time = datetime.strptime(request.form["scheduled_time"], "%Y-%m-%dT%H:%M")
    predicted_duration = predictor.predict_consultation_duration(patient, department)

    appt = Appointment(
        patient_id=patient.id,
        doctor_id=doctor.id,
        department_id=department.id,
        scheduled_time=scheduled_time,
        predicted_duration=predicted_duration,
        status="scheduled",
    )
    db.session.add(appt)
    db.session.commit()

    flash(f"Appointment scheduled. AI predicted duration: {predicted_duration:.0f} min", "success")
    return redirect(url_for("appointments"))


@app.route("/optimization")
@login_required
def optimization():
    """AI optimization page with explainable recommendations."""
    logs = OptimizationLog.query.order_by(OptimizationLog.created_at.desc()).all()
    logs_data = [log.to_dict() for log in logs]

    summary = {
        "applied": len([l for l in logs if l.applied]),
        "pending": len([l for l in logs if not l.applied]),
        "total_saved": round(sum(l.impact_score or 0 for l in logs if l.applied), 1),
    }

    return render_template("optimization.html", logs=logs_data, summary=summary)


@app.route("/optimization/run", methods=["POST"])
@login_required
def run_optimization():
    """Trigger the AI optimization engine."""
    departments = Department.query.all()
    doctors = Doctor.query.all()
    queue_entries = QueueEntry.query.filter_by(status="waiting").all()
    appointments_list = Appointment.query.filter_by(status="scheduled").all()

    recommendations = optimizer.optimize(departments, doctors, queue_entries, appointments_list)

    if recommendations:
        flash(f"AI generated {len(recommendations)} optimization recommendations.", "info")
    else:
        flash("No optimizations needed. System is running efficiently.", "success")

    return redirect(url_for("optimization"))


@app.route("/optimization/<int:log_id>/apply", methods=["POST"])
@login_required
def apply_optimization(log_id):
    """Apply a specific optimization recommendation."""
    if optimizer.apply_recommendation(log_id):
        flash("Optimization applied successfully.", "success")
    else:
        flash("Could not apply optimization.", "danger")
    return redirect(url_for("optimization"))


@app.route("/simulation")
@login_required
def simulation():
    """What-if simulation page."""
    departments = Department.query.all()
    dept_stats = {}
    for dept in departments:
        doc_count = Doctor.query.filter_by(department_id=dept.id).filter(
            Doctor.status != "offline"
        ).count()
        queue_count = QueueEntry.query.filter_by(
            department_id=dept.id, status="waiting"
        ).count()
        dept_stats[dept.id] = {"doctors": doc_count, "queue": queue_count}

    return render_template("simulation.html",
        departments=[d.to_dict() for d in departments],
        dept_stats=dept_stats,
        result=None,
        selected_dept=None,
        selected_change=1,
    )


@app.route("/simulation/run", methods=["POST"])
@login_required
def run_simulation():
    """Run a what-if staffing simulation."""
    dept_id = int(request.form["department_id"])
    doctor_change = int(request.form["doctor_change"])

    department = Department.query.get_or_404(dept_id)
    queue_entries = QueueEntry.query.filter_by(status="waiting").all()
    doctors = Doctor.query.all()

    result = optimizer.simulate_staffing_change(department, doctor_change, queue_entries, doctors)

    departments = Department.query.all()
    dept_stats = {}
    for dept in departments:
        doc_count = Doctor.query.filter_by(department_id=dept.id).filter(
            Doctor.status != "offline"
        ).count()
        queue_count = QueueEntry.query.filter_by(
            department_id=dept.id, status="waiting"
        ).count()
        dept_stats[dept.id] = {"doctors": doc_count, "queue": queue_count}

    return render_template("simulation.html",
        departments=[d.to_dict() for d in departments],
        dept_stats=dept_stats,
        result=result,
        selected_dept=dept_id,
        selected_change=doctor_change,
    )


# ── API Endpoints ──────────────────────────────────────────────────────────

@app.route("/api/queue-status")
def api_queue_status():
    """JSON API: current queue status for dashboard auto-refresh."""
    stats, bottlenecks = get_dashboard_stats()
    return jsonify(stats)


@app.route("/api/doctor-utilization")
def api_doctor_utilization():
    """JSON API: doctor utilization data for charts."""
    doctors = Doctor.query.filter(Doctor.status != "offline").all()
    return jsonify([d.to_dict() for d in doctors])


@app.route("/api/predictions")
def api_predictions():
    """JSON API: current wait time predictions per department."""
    departments = Department.query.all()
    predictions = []
    for dept in departments:
        queue_entries = QueueEntry.query.filter_by(
            department_id=dept.id, status="waiting"
        ).all()
        doctors = Doctor.query.filter_by(department_id=dept.id).filter(
            Doctor.status != "offline"
        ).all()
        wait = predictor.predict_wait_time(queue_entries, dept, doctors)
        predictions.append({
            "department": dept.name,
            "department_id": dept.id,
            "estimated_wait": round(wait, 1),
            "queue_depth": len(queue_entries),
            "available_doctors": len([d for d in doctors if d.status == "available"]),
        })
    return jsonify(predictions)


@app.route("/api/optimize", methods=["POST"])
def api_optimize():
    """JSON API: trigger optimization and return recommendations."""
    departments = Department.query.all()
    doctors = Doctor.query.all()
    queue_entries = QueueEntry.query.filter_by(status="waiting").all()
    appointments_list = Appointment.query.filter_by(status="scheduled").all()

    recommendations = optimizer.optimize(departments, doctors, queue_entries, appointments_list)
    explained = [explainer.explain_recommendation(r) for r in recommendations]
    return jsonify(explained)


@app.route("/api/simulate", methods=["POST"])
def api_simulate():
    """JSON API: run staffing simulation."""
    data = request.get_json()
    dept_id = data.get("department_id")
    doctor_change = data.get("doctor_change", 1)

    department = Department.query.get_or_404(dept_id)
    queue_entries = QueueEntry.query.filter_by(status="waiting").all()
    doctors = Doctor.query.all()

    result = optimizer.simulate_staffing_change(department, doctor_change, queue_entries, doctors)
    return jsonify(result)


# ── User Booking API Endpoints ────────────────────────────────────────────

@app.route("/api/doctors-by-department/<int:department_id>")
def api_doctors_by_department(department_id):
    """JSON API: get available doctors for a specific department."""
    doctors = Doctor.query.filter_by(department_id=department_id).filter(
        Doctor.status != "offline"
    ).all()
    
    doctor_data = []
    for doctor in doctors:
        doctor_data.append({
            "id": doctor.id,
            "name": doctor.name,
            "specialty": doctor.specialty,
            "status": doctor.status,
            "patients_seen_today": doctor.patients_seen_today,
        })
    
    return jsonify(doctor_data)


@app.route("/api/booking-stats")
def api_booking_stats():
    """JSON API: get current waiting statistics for booking page."""
    departments = Department.query.all()
    stats = []
    
    for dept in departments:
        queue_entries = QueueEntry.query.filter_by(
            department_id=dept.id, status="waiting"
        ).all()
        doctors = Doctor.query.filter_by(department_id=dept.id).filter(
            Doctor.status != "offline"
        ).all()
        
        available_doctors = [d for d in doctors if d.status == "available"]
        
        if queue_entries and doctors:
            avg_wait = round(sum(q.estimated_wait_minutes for q in queue_entries) / len(queue_entries), 1)
        else:
            avg_wait = 0
        
        stats.append({
            "department_id": dept.id,
            "department_name": dept.name,
            "total_waiting_patients": len(queue_entries),
            "avg_wait_time": avg_wait,
            "total_doctors": len(doctors),
            "available_doctors": len(available_doctors),
            "avg_consultation_time": dept.avg_consultation_minutes,
        })
    
    return jsonify(stats)


# ── Main ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Only seed data if explicitly requested
    if "--seed" in sys.argv:
        from seed_data import seed_all
        print("Seeding database...")
        seed_all(app)
        print("Database seeded successfully!")

    print("\n  PatientFlow AI - Real-Time Patient Queue Optimizer")
    print("  http://127.0.0.1:5000\n")
    app.run(debug=True, port=5000)
