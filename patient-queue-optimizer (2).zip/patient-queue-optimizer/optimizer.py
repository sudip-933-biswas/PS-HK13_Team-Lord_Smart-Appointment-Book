"""
Optimizer Module
Dynamic scheduling optimization using greedy + multi-objective strategies.
Handles slot reassignment, no-show recovery, emergency insertion, and load balancing.
"""
import numpy as np
from datetime import datetime
from models import db, Doctor, Patient, QueueEntry, Appointment, OptimizationLog
from predictor import PatientPredictor


class QueueOptimizer:
    """Real-time queue optimization engine."""

    def __init__(self):
        self.predictor = PatientPredictor()

    def optimize(self, departments, doctors, queue_entries, appointments):
        """
        Run full optimization pass. Returns list of recommended actions.
        Each action: {type, description, reason, confidence, impact, data}
        """
        recommendations = []

        # 1. Load balancing: redistribute patients across doctors
        recommendations.extend(self._optimize_load_balance(departments, doctors, queue_entries))

        # 2. No-show recovery: fill gaps from no-shows
        recommendations.extend(self._optimize_no_show_recovery(appointments, queue_entries, doctors))

        # 3. Emergency prioritization
        recommendations.extend(self._optimize_emergency_priority(queue_entries, doctors))

        # 4. Delay mitigation: proactively shift patients if delays detected
        recommendations.extend(self._optimize_delay_mitigation(appointments, doctors))

        # Sort by impact score descending
        recommendations.sort(key=lambda x: x.get("impact", 0), reverse=True)

        # Log recommendations
        for rec in recommendations:
            log = OptimizationLog(
                action_type=rec["type"],
                description=rec["description"],
                reason=rec["reason"],
                confidence=rec["confidence"],
                impact_score=rec["impact"],
            )
            db.session.add(log)
        if recommendations:
            db.session.commit()

        return recommendations

    def _optimize_load_balance(self, departments, doctors, queue_entries):
        """Reassign waiting patients to less-loaded doctors within same department."""
        recommendations = []

        for dept in departments:
            dept_docs = [d for d in doctors if d.department_id == dept.id and d.status != "offline"]
            if len(dept_docs) < 2:
                continue

            # Calculate load per doctor
            doc_loads = {}
            for doc in dept_docs:
                # Load = patients in queue assigned to this doc + current consultation
                assigned = len([q for q in queue_entries
                                if q.department_id == dept.id and q.status == "waiting"])
                doc_loads[doc.id] = {
                    "doctor": doc,
                    "total_minutes": doc.total_minutes_today,
                    "patients_seen": doc.patients_seen_today,
                    "is_busy": doc.status == "busy",
                }

            if not doc_loads:
                continue

            # Find overloaded and underloaded doctors
            minutes_list = [v["total_minutes"] for v in doc_loads.values()]
            avg_minutes = np.mean(minutes_list)
            std_minutes = np.std(minutes_list) if len(minutes_list) > 1 else 0

            for doc_id, load in doc_loads.items():
                if load["total_minutes"] > avg_minutes + std_minutes and std_minutes > 10:
                    # Find least loaded doctor
                    least_loaded = min(doc_loads.values(), key=lambda x: x["total_minutes"])
                    if least_loaded["doctor"].id != doc_id and least_loaded["doctor"].status == "available":
                        overload_amount = load["total_minutes"] - avg_minutes
                        recommendations.append({
                            "type": "reassign",
                            "description": f"Redirect next patient from Dr. {load['doctor'].name} "
                                           f"to Dr. {least_loaded['doctor'].name} in {dept.name}",
                            "reason": f"Dr. {load['doctor'].name} has worked {load['total_minutes']:.0f} min today "
                                      f"(avg: {avg_minutes:.0f} min). Dr. {least_loaded['doctor'].name} has only "
                                      f"worked {least_loaded['total_minutes']:.0f} min. Redistribution saves "
                                      f"~{overload_amount:.0f} min of imbalance.",
                            "confidence": min(0.6 + (overload_amount / 100), 0.95),
                            "impact": overload_amount * 0.5,
                            "data": {
                                "from_doctor_id": doc_id,
                                "to_doctor_id": least_loaded["doctor"].id,
                                "department_id": dept.id,
                            },
                        })
        return recommendations

    def _optimize_no_show_recovery(self, appointments, queue_entries, doctors):
        """Detect likely no-shows and recommend filling their slots."""
        recommendations = []
        now = datetime.utcnow()

        for appt in appointments:
            if appt.status != "scheduled":
                continue

            # Check if appointment is overdue (past scheduled time by >10 min)
            if appt.scheduled_time and (now - appt.scheduled_time).total_seconds() > 600:
                # Find next waiting patient in same department
                waiting = [q for q in queue_entries
                           if q.department_id == appt.department_id and q.status == "waiting"]
                waiting.sort(key=lambda q: (-q.patient.priority_score if q.patient else 0, q.position))

                if waiting:
                    next_patient = waiting[0]
                    minutes_late = (now - appt.scheduled_time).total_seconds() / 60
                    recommendations.append({
                        "type": "slot_fill",
                        "description": f"Patient {appt.patient.name if appt.patient else 'Unknown'} is "
                                       f"{minutes_late:.0f} min late (likely no-show). "
                                       f"Offer slot to {next_patient.patient.name if next_patient.patient else 'next patient'}.",
                        "reason": f"Appointment was scheduled for {appt.scheduled_time.strftime('%H:%M')} "
                                  f"but patient hasn't arrived after {minutes_late:.0f} min. "
                                  f"Filling this slot saves ~{appt.predicted_duration or 15:.0f} min of idle time.",
                        "confidence": min(0.5 + (minutes_late / 30), 0.9),
                        "impact": appt.predicted_duration or 15,
                        "data": {
                            "no_show_appointment_id": appt.id,
                            "fill_patient_id": next_patient.patient_id,
                            "doctor_id": appt.doctor_id,
                        },
                    })
        return recommendations

    def _optimize_emergency_priority(self, queue_entries, doctors):
        """Boost emergency patients to front of queue."""
        recommendations = []
        waiting = [q for q in queue_entries if q.status == "waiting"]

        for entry in waiting:
            if entry.patient and entry.patient.is_emergency and entry.position > 1:
                recommendations.append({
                    "type": "priority_boost",
                    "description": f"Move emergency patient {entry.patient.name} from position "
                                   f"#{entry.position} to #1 in {entry.department.name if entry.department else 'queue'}.",
                    "reason": f"Patient {entry.patient.name} (age {entry.patient.age}) is flagged as emergency "
                              f"with condition: {entry.patient.condition}. Emergency protocols require "
                              f"immediate attention. Current wait: {entry.estimated_wait_minutes:.0f} min.",
                    "confidence": 0.98,
                    "impact": entry.estimated_wait_minutes,
                    "data": {
                        "queue_entry_id": entry.id,
                        "patient_id": entry.patient_id,
                        "new_position": 1,
                    },
                })
        return recommendations

    def _optimize_delay_mitigation(self, appointments, doctors):
        """Detect appointments running over and recommend adjustments."""
        recommendations = []
        now = datetime.utcnow()

        for doc in doctors:
            if doc.status != "busy" or not doc.consultation_start:
                continue

            elapsed = (now - doc.consultation_start).total_seconds() / 60
            avg_duration = doc.department.avg_consultation_minutes if doc.department else 15

            if elapsed > avg_duration * 1.3:  # 30% over expected
                overrun = elapsed - avg_duration
                # Find next appointments for this doctor
                upcoming = [a for a in appointments
                            if a.doctor_id == doc.id and a.status == "scheduled"]
                upcoming.sort(key=lambda a: a.scheduled_time)

                if upcoming:
                    # Find available doctor in same department
                    same_dept_docs = [d for d in doctors
                                      if d.department_id == doc.department_id
                                      and d.status == "available"
                                      and d.id != doc.id]
                    if same_dept_docs:
                        alt_doc = min(same_dept_docs, key=lambda d: d.total_minutes_today)
                        next_appt = upcoming[0]
                        recommendations.append({
                            "type": "delay_mitigation",
                            "description": f"Dr. {doc.name}'s current consultation is {overrun:.0f} min over. "
                                           f"Shift next patient ({next_appt.patient.name if next_appt.patient else 'Unknown'}) "
                                           f"to Dr. {alt_doc.name}.",
                            "reason": f"Dr. {doc.name} started consultation {elapsed:.0f} min ago "
                                      f"(expected: {avg_duration:.0f} min). Next patient "
                                      f"({next_appt.scheduled_time.strftime('%H:%M')}) will be delayed by "
                                      f"~{overrun:.0f} min. Dr. {alt_doc.name} is available now.",
                            "confidence": min(0.5 + (overrun / 20), 0.9),
                            "impact": overrun,
                            "data": {
                                "appointment_id": next_appt.id,
                                "from_doctor_id": doc.id,
                                "to_doctor_id": alt_doc.id,
                            },
                        })
        return recommendations

    def apply_recommendation(self, recommendation_id):
        """Apply a specific optimization recommendation."""
        log = OptimizationLog.query.get(recommendation_id)
        if log and not log.applied:
            log.applied = True
            db.session.commit()
            return True
        return False

    def simulate_staffing_change(self, department, doctor_count_change, queue_entries, doctors):
        """
        What-if simulation: predict impact of adding/removing doctors.
        Returns projected metrics.
        """
        dept_queue = [q for q in queue_entries
                      if q.department_id == department.id and q.status == "waiting"]
        current_docs = [d for d in doctors
                        if d.department_id == department.id and d.status != "offline"]

        current_count = len(current_docs)
        new_count = max(1, current_count + doctor_count_change)
        queue_depth = len(dept_queue)

        # Current metrics
        current_wait = queue_depth * department.avg_consultation_minutes / max(current_count, 1)
        current_utilization = min(queue_depth / max(current_count, 1) * 40, 100)

        # Projected metrics
        projected_wait = queue_depth * department.avg_consultation_minutes / new_count
        projected_utilization = min(queue_depth / new_count * 40, 100)

        # Cost factor (simplified)
        cost_per_doctor_hour = 150  # $150/hr
        hours_remaining = max(0, 17 - datetime.now().hour)
        cost_change = doctor_count_change * cost_per_doctor_hour * hours_remaining

        return {
            "department": department.name,
            "current_doctors": current_count,
            "projected_doctors": new_count,
            "change": doctor_count_change,
            "current_queue": queue_depth,
            "current_avg_wait": round(current_wait, 1),
            "projected_avg_wait": round(projected_wait, 1),
            "wait_improvement": round(current_wait - projected_wait, 1),
            "current_utilization": round(current_utilization, 1),
            "projected_utilization": round(projected_utilization, 1),
            "additional_cost": round(cost_change, 2),
            "recommendation": self._staffing_recommendation(
                current_wait, projected_wait, cost_change, doctor_count_change
            ),
        }

    def _staffing_recommendation(self, current_wait, projected_wait, cost_change, change):
        """Generate recommendation text for staffing simulation."""
        improvement = current_wait - projected_wait
        if change > 0:
            if improvement > 15:
                return f"Strongly recommended. Adding staff reduces avg wait by {improvement:.0f} min."
            elif improvement > 5:
                return f"Recommended. Moderate improvement of {improvement:.0f} min in avg wait time."
            else:
                return f"Low impact. Only {improvement:.0f} min improvement. Consider other optimizations first."
        else:
            if projected_wait > 30:
                return f"Not recommended. Avg wait would increase to {projected_wait:.0f} min."
            elif projected_wait > 15:
                return f"Caution. Wait times increase to {projected_wait:.0f} min but savings of ${abs(cost_change):.0f}."
            else:
                return f"Acceptable. Wait times remain manageable at {projected_wait:.0f} min. Saves ${abs(cost_change):.0f}."
