"""Seed the database with realistic sample data for demo."""
import random
from datetime import datetime, timedelta
from models import db, Admin, Department, Doctor, Patient, Appointment, QueueEntry, OptimizationLog
from predictor import PatientPredictor

predictor = PatientPredictor()


def seed_all(app):
    """Seed all data within app context."""
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()

        # 1. Departments
        departments = [
            Department(name="General Medicine", avg_consultation_minutes=15),
            Department(name="Cardiology", avg_consultation_minutes=25),
            Department(name="Orthopedics", avg_consultation_minutes=20),
            Department(name="Pediatrics", avg_consultation_minutes=18),
            Department(name="Dermatology", avg_consultation_minutes=12),
            Department(name="ENT", avg_consultation_minutes=15),
        ]
        db.session.add_all(departments)
        db.session.flush()

        # 2. Doctors
        doctor_data = [
            ("Dr. Sarah Johnson", "General Practice", "MBBS, MD (General Medicine), FRACGP", departments[0].id, "busy", 6, 95),
            ("Dr. Michael Chen", "Family Medicine", "MD, CCFP, Diploma in Family Medicine", departments[0].id, "available", 4, 62),
            ("Dr. Emily Rodriguez", "Internal Medicine", "MBBS, MD (Medicine), FACP, MRCP(UK)", departments[0].id, "busy", 7, 110),
            ("Dr. James Wilson", "Interventional Cardiologist", "MBBS, MD (Cardiology), DM (Cardiology), FACC, FESC", departments[1].id, "busy", 5, 130),
            ("Dr. Lisa Park", "Clinical Cardiologist", "MD, FACC, Board Certified in Cardiovascular Disease", departments[1].id, "available", 3, 78),
            ("Dr. Robert Kim", "Joint Replacement Surgeon", "MBBS, MS (Orthopedics), MCh (Orthopedics), FRCS (Edin)", departments[2].id, "busy", 4, 85),
            ("Dr. Amanda Foster", "Sports Medicine Specialist", "MD, Orthopedic Surgery Fellowship, FIFA Medical Diploma", departments[2].id, "break", 3, 65),
            ("Dr. David Lee", "Pediatric Intensivist", "MBBS, MD (Pediatrics), Fellowship in Pediatric Critical Care", departments[3].id, "busy", 8, 145),
            ("Dr. Maria Garcia", "Developmental Pediatrician", "MD, Board Certified in Pediatrics, Developmental-Behavioral Pediatrics Fellowship", departments[3].id, "available", 5, 90),
            ("Dr. Thomas Brown", "Cosmetic Dermatologist", "MBBS, MD (Dermatology), Fellowship in Cosmetic Dermatology", departments[4].id, "busy", 9, 108),
            ("Dr. Jennifer Adams", "ENT Surgeon", "MBBS, MS (ENT), DLO, Fellowship in Rhinology", departments[5].id, "available", 4, 60),
            ("Dr. William Taylor", "Head and Neck Surgeon", "MS (ENT), Fellowship in Head & Neck Surgery, ABS Certified", departments[5].id, "busy", 6, 92),
        ]

        doctors = []
        now = datetime.utcnow()
        for name, spec, qualification, dept_id, status, seen, mins in doctor_data:
            doc = Doctor(
                name=name, specialty=spec, qualification=qualification, department_id=dept_id,
                status=status, patients_seen_today=seen, total_minutes_today=mins,
            )
            if status == "busy":
                doc.consultation_start = now - timedelta(minutes=random.randint(3, 20))
            doctors.append(doc)
        db.session.add_all(doctors)
        db.session.flush()

        # 3. Patients
        patient_data = [
            ("Amit Sharma", 45, "M", "Chest Pain", False, True),
            ("Priya Patel", 32, "F", "Fever", False, False),
            ("Rahul Kumar", 8, "M", "Fracture", True, False),
            ("Sneha Reddy", 67, "F", "Chronic Disease Management", False, False),
            ("Vikram Singh", 28, "M", "Skin Rash", True, False),
            ("Ananya Gupta", 55, "F", "Breathing Difficulty", False, True),
            ("Rohan Joshi", 4, "M", "Fever", True, False),
            ("Meera Iyer", 72, "F", "Follow-up", False, False),
            ("Arjun Nair", 38, "M", "Headache", True, False),
            ("Kavitha Menon", 22, "F", "Routine Checkup", False, False),
            ("Sanjay Verma", 50, "M", "Abdominal Pain", True, False),
            ("Divya Krishnan", 15, "F", "Skin Rash", True, False),
            ("Rajesh Pillai", 60, "M", "Post-surgery Review", False, False),
            ("Lakshmi Bhat", 42, "F", "Lab Results Review", False, False),
            ("Nikhil Rao", 35, "M", "Vaccination", True, False),
            ("Pooja Desai", 78, "F", "Breathing Difficulty", False, True),
            ("Karthik Suresh", 25, "M", "Routine Checkup", True, False),
            ("Revathi Mohan", 48, "F", "Chest Pain", False, False),
            ("Arun Prasad", 6, "M", "Fever", True, False),
            ("Deepa Nambiar", 33, "F", "Follow-up", False, False),
        ]

        patients = []
        for i, (name, age, gender, condition, walk_in, emergency) in enumerate(patient_data):
            arrival = now - timedelta(minutes=random.randint(5, 120))
            p = Patient(
                name=name, age=age, gender=gender, condition=condition,
                is_walk_in=walk_in, is_emergency=emergency, arrival_time=arrival,
            )
            p.priority_score = predictor.compute_priority_score(p)
            if emergency:
                p.status = "waiting"
            elif i < 5:
                p.status = "in-consultation"
            elif i < 15:
                p.status = "waiting"
            else:
                p.status = "registered"
            patients.append(p)
        db.session.add_all(patients)
        db.session.flush()

        # Assign current patients to busy doctors
        busy_doctors = [d for d in doctors if d.status == "busy"]
        in_consult = [p for p in patients if p.status == "in-consultation"]
        for doc, pat in zip(busy_doctors, in_consult):
            doc.current_patient_id = pat.id

        # 4. Queue Entries
        waiting_patients = [p for p in patients if p.status == "waiting"]
        dept_queues = {}
        for p in waiting_patients:
            # Assign to a department based on condition
            if p.condition and "chest" in p.condition.lower():
                dept_id = departments[1].id  # Cardiology
            elif p.condition and "fracture" in p.condition.lower():
                dept_id = departments[2].id  # Ortho
            elif p.condition and ("skin" in p.condition.lower() or "rash" in p.condition.lower()):
                dept_id = departments[4].id  # Derma
            elif p.age and p.age < 12:
                dept_id = departments[3].id  # Pediatrics
            elif p.condition and "breath" in p.condition.lower():
                dept_id = departments[0].id  # General
            else:
                dept_id = departments[0].id  # General

            if dept_id not in dept_queues:
                dept_queues[dept_id] = 0
            dept_queues[dept_id] += 1

            dept = next(d for d in departments if d.id == dept_id)
            dept_docs = [d for d in doctors if d.department_id == dept_id]
            wait_est = predictor.predict_wait_time([], dept, dept_docs) + dept_queues[dept_id] * 5

            qe = QueueEntry(
                patient_id=p.id, department_id=dept_id,
                position=dept_queues[dept_id],
                estimated_wait_minutes=max(0, wait_est),
                joined_at=p.arrival_time,
            )
            db.session.add(qe)

        # 5. Appointments
        for i, p in enumerate(patients[:12]):
            dept_id = random.choice([d.id for d in departments])
            dept_docs = [d for d in doctors if d.department_id == dept_id]
            if not dept_docs:
                continue
            doc = random.choice(dept_docs)
            dept = next(d for d in departments if d.id == dept_id)

            sched_time = now + timedelta(minutes=random.randint(-60, 120))
            pred_dur = predictor.predict_consultation_duration(p, dept)

            status = "scheduled"
            if p.status == "in-consultation":
                status = "in-progress"
            elif p.status == "completed":
                status = "completed"

            appt = Appointment(
                patient_id=p.id, doctor_id=doc.id, department_id=dept_id,
                scheduled_time=sched_time, predicted_duration=pred_dur,
                status=status, delay_minutes=random.uniform(0, 15) if random.random() > 0.5 else 0,
            )
            db.session.add(appt)

        # 6. Sample optimization logs
        log_data = [
            ("reassign", "Redirected patient from Dr. Johnson to Dr. Chen",
             "Dr. Johnson workload 40% above average. Dr. Chen had capacity.", 0.85, 12.0, True),
            ("slot_fill", "Filled no-show slot for 10:30 AM with walk-in patient",
             "Original patient 15 min late. Walk-in Vikram Singh waiting 25 min.", 0.78, 15.0, True),
            ("priority_boost", "Emergency patient Amit Sharma moved to position #1",
             "Chest pain reported. Emergency protocol activated.", 0.98, 20.0, True),
            ("delay_mitigation", "Shifted patient from Dr. Wilson to Dr. Park",
             "Dr. Wilson's consultation running 12 min over. Dr. Park available.", 0.72, 12.0, False),
            ("reassign", "Consider moving 2 patients from General Medicine to available ENT doctor",
             "General Medicine queue ratio 3.5:1. Dr. Adams available in ENT.", 0.65, 8.0, False),
        ]
        for atype, desc, reason, conf, impact, applied in log_data:
            log = OptimizationLog(
                action_type=atype, description=desc, reason=reason,
                confidence=conf, impact_score=impact, applied=applied,
                created_at=now - timedelta(minutes=random.randint(5, 180)),
            )
            db.session.add(log)

        # 7. Default admin account
        default_admin = Admin(
            username="admin123",
            email="admin@patientflow.ai",
            full_name="Hospital Admin",
            role="superadmin",
        )
        default_admin.set_password("admin@123")
        db.session.add(default_admin)

        db.session.commit()
        print(f"Seeded: {len(departments)} departments, {len(doctors)} doctors, "
              f"{len(patients)} patients, {len(waiting_patients)} queue entries, "
              f"{len(log_data)} optimization logs, 1 admin (admin123/admin@123)")
