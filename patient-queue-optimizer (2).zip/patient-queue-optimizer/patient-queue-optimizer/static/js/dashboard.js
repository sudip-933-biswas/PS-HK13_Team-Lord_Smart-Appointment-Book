// Dashboard Charts & Auto-Refresh
let doctorChart = null;
let deptChart = null;

function initDoctorChart(data) {
    const ctx = document.getElementById('doctorUtilChart');
    if (!ctx) return;

    const colors = data.map(d => {
        if (d.status === 'busy') return 'rgba(220, 53, 69, 0.8)';
        if (d.status === 'available') return 'rgba(25, 135, 84, 0.8)';
        if (d.status === 'break') return 'rgba(255, 193, 7, 0.8)';
        return 'rgba(108, 117, 125, 0.8)';
    });

    if (doctorChart) doctorChart.destroy();

    doctorChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.name.replace('Dr. ', '')),
            datasets: [{
                label: 'Minutes Today',
                data: data.map(d => d.total_minutes_today),
                backgroundColor: colors,
                borderRadius: 6,
                barThickness: 20,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: function(ctx) {
                            const doc = data[ctx.dataIndex];
                            return `Status: ${doc.status}\nPatients: ${doc.patients_seen_today}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: { display: true, text: 'Minutes' },
                    grid: { color: 'rgba(0,0,0,0.05)' }
                },
                x: {
                    grid: { display: false },
                    ticks: { font: { size: 10 } }
                }
            }
        }
    });
}

function initDeptChart(data) {
    const ctx = document.getElementById('deptQueueChart');
    if (!ctx) return;

    const colors = [
        'rgba(99, 102, 241, 0.8)',
        'rgba(236, 72, 153, 0.8)',
        'rgba(34, 197, 94, 0.8)',
        'rgba(245, 158, 11, 0.8)',
        'rgba(6, 182, 212, 0.8)',
        'rgba(168, 85, 247, 0.8)',
    ];

    if (deptChart) deptChart.destroy();

    deptChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.map(d => d.name),
            datasets: [{
                data: data.map(d => d.queue_count),
                backgroundColor: colors.slice(0, data.length),
                borderWidth: 2,
                borderColor: '#fff',
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { font: { size: 11 }, padding: 12 }
                },
                tooltip: {
                    callbacks: {
                        afterLabel: function(ctx) {
                            const dept = data[ctx.dataIndex];
                            return `Doctors: ${dept.doctor_count}\nAvg time: ${dept.avg_time} min`;
                        }
                    }
                }
            },
            cutout: '60%',
        }
    });
}

function refreshDashboard() {
    // Refresh queue status via API
    fetch('/api/queue-status')
        .then(r => r.json())
        .then(data => {
            // Update KPIs
            const waiting = document.getElementById('kpi-total-waiting');
            if (waiting) waiting.textContent = data.total_waiting;

            const avgWait = document.getElementById('kpi-avg-wait');
            if (avgWait) avgWait.textContent = data.avg_wait_time + ' min';

            const activeDocs = document.getElementById('kpi-active-docs');
            if (activeDocs) activeDocs.textContent = data.active_doctors;

            const bottlenecks = document.getElementById('kpi-bottlenecks');
            if (bottlenecks) bottlenecks.textContent = data.bottleneck_count;
        })
        .catch(err => console.error('Refresh failed:', err));

    // Refresh doctor utilization
    fetch('/api/doctor-utilization')
        .then(r => r.json())
        .then(data => initDoctorChart(data))
        .catch(err => console.error('Doctor chart refresh failed:', err));
}

function startAutoRefresh(interval) {
    setInterval(refreshDashboard, interval);
}
