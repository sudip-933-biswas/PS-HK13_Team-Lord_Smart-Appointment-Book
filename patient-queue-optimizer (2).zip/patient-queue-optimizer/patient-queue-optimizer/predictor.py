"""
AI Predictor Module
Uses statistical models to predict consultation durations, wait times, and delay probabilities.
"""
import numpy as np
from datetime import datetime, timedelta


class PatientPredictor:
    """Predicts consultation duration and wait times using statistical + ML-inspired models."""

    # Base factors that influence consultation duration
    AGE_FACTOR = {
        "child": 1.2,       # 0-12: slightly longer (parents involved)
        "teen": 0.9,         # 13-19: typically quick
        "adult": 1.0,        # 20-59: baseline
        "senior": 1.4,       # 60+: longer consultations
    }

    CONDITION_SEVERITY = {
        "routine checkup": 0.7,
        "follow-up": 0.6,
        "fever": 0.9,
        "chest pain": 1.5,
        "fracture": 1.3,
        "skin rash": 0.8,
        "headache": 0.85,
        "abdominal pain": 1.2,
        "breathing difficulty": 1.6,
        "post-surgery review": 1.1,
        "vaccination": 0.5,
        "lab results review": 0.6,
        "chronic disease management": 1.3,
        "emergency trauma": 2.0,
    }

    TIME_OF_DAY_FACTOR = {
        "morning": 0.95,     # 8-12: doctors are fresh
        "afternoon": 1.05,   # 12-16: slight slowdown
        "evening": 1.15,     # 16-20: fatigue factor
    }

    def _get_age_group(self, age):
        if age <= 12:
            return "child"
        elif age <= 19:
            return "teen"
        elif age <= 59:
            return "adult"
        return "senior"

    def _get_time_period(self):
        hour = datetime.now().hour
        if hour < 12:
            return "morning"
        elif hour < 16:
            return "afternoon"
        return "evening"

    def predict_consultation_duration(self, patient, department):
        """
        Predict consultation duration in minutes.
        Uses a multiplicative model: base_time * age_factor * severity * time_factor + noise
        """
        base_time = department.avg_consultation_minutes

        # Age factor
        age_group = self._get_age_group(patient.age or 30)
        age_factor = self.AGE_FACTOR[age_group]

        # Condition severity factor
        condition = (patient.condition or "routine checkup").lower()
        severity = self.CONDITION_SEVERITY.get(condition, 1.0)

        # Time of day factor
        time_factor = self.TIME_OF_DAY_FACTOR[self._get_time_period()]

        # Emergency boost
        emergency_factor = 1.5 if patient.is_emergency else 1.0

        # Add controlled randomness to simulate real-world variation
        noise = np.random.normal(0, 2)

        predicted = base_time * age_factor * severity * time_factor * emergency_factor + noise
        return max(5.0, round(predicted, 1))

    def predict_wait_time(self, queue_entries, department, doctors):
        """
        Predict wait time for a patient based on queue state.
        Models: queue_depth / available_doctors * avg_consultation_time
        """
        waiting = [q for q in queue_entries if q.status == "waiting"]
        queue_depth = len(waiting)

        available_docs = len([d for d in doctors if d.status == "available"])
        busy_docs = [d for d in doctors if d.status == "busy"]

        if available_docs > 0 and queue_depth == 0:
            return 0.0

        if available_docs == 0 and len(busy_docs) == 0:
            return queue_depth * department.avg_consultation_minutes

        # Estimate remaining time for busy doctors
        remaining_times = []
        for doc in busy_docs:
            if doc.consultation_start:
                elapsed = (datetime.utcnow() - doc.consultation_start).total_seconds() / 60
                avg = department.avg_consultation_minutes
                remaining = max(0, avg - elapsed)
                remaining_times.append(remaining)

        # Effective service rate
        total_docs = available_docs + len(busy_docs)
        if total_docs == 0:
            return queue_depth * department.avg_consultation_minutes

        avg_remaining = np.mean(remaining_times) if remaining_times else 0
        service_rate = department.avg_consultation_minutes / total_docs

        wait_time = (queue_depth * service_rate) + (avg_remaining if available_docs == 0 else 0)

        # Add slight noise
        noise = np.random.normal(0, 1)
        return max(0.0, round(wait_time + noise, 1))

    def predict_delay_probability(self, appointment, doctor):
        """
        Predict probability that an appointment will be delayed.
        Factors: doctor's current load, time of day, historical overruns.
        """
        base_prob = 0.15  # 15% base delay probability

        # Load factor: more patients seen = higher delay probability
        load_factor = min(doctor.patients_seen_today * 0.03, 0.3)

        # Time factor: later in day = more delays
        hour = datetime.now().hour
        time_factor = max(0, (hour - 8) * 0.02)

        # Overrun factor: if doctor is currently running over
        overrun_factor = 0.0
        if doctor.status == "busy" and doctor.consultation_start:
            elapsed = (datetime.utcnow() - doctor.consultation_start).total_seconds() / 60
            avg = doctor.department.avg_consultation_minutes if doctor.department else 15
            if elapsed > avg:
                overrun_factor = min((elapsed - avg) / avg * 0.3, 0.4)

        probability = base_prob + load_factor + time_factor + overrun_factor
        return min(round(probability, 2), 0.95)

    def compute_priority_score(self, patient):
        """
        Compute patient priority score (0-1) using multiple factors.
        Higher score = higher priority.
        """
        score = 0.5  # base

        # Emergency override
        if patient.is_emergency:
            return 0.95

        # Age factor (very young and very old get priority)
        age = patient.age or 30
        if age < 5 or age > 75:
            score += 0.15
        elif age < 12 or age > 65:
            score += 0.08

        # Condition severity
        condition = (patient.condition or "routine checkup").lower()
        severity = self.CONDITION_SEVERITY.get(condition, 1.0)
        score += (severity - 1.0) * 0.2

        # Wait time factor (longer wait = gradually increase priority)
        if patient.arrival_time:
            waited_minutes = (datetime.utcnow() - patient.arrival_time).total_seconds() / 60
            score += min(waited_minutes * 0.005, 0.15)

        return min(max(round(score, 2), 0.0), 1.0)

    def predict_bottlenecks(self, departments, queue_entries, doctors):
        """
        Identify departments likely to become bottlenecks.
        Returns list of (department, severity, reason).
        """
        bottlenecks = []
        for dept in departments:
            dept_queue = [q for q in queue_entries if q.department_id == dept.id and q.status == "waiting"]
            dept_docs = [d for d in doctors if d.department_id == dept.id]
            available = [d for d in dept_docs if d.status == "available"]
            busy = [d for d in dept_docs if d.status == "busy"]

            queue_depth = len(dept_queue)
            total_docs = len(dept_docs)

            if total_docs == 0:
                continue

            # Queue-to-doctor ratio
            ratio = queue_depth / total_docs
            if ratio > 3:
                severity = "critical"
            elif ratio > 2:
                severity = "high"
            elif ratio > 1.5:
                severity = "medium"
            else:
                continue

            avg_wait = queue_depth * dept.avg_consultation_minutes / max(len(available) + len(busy), 1)

            bottlenecks.append({
                "department": dept.name,
                "department_id": dept.id,
                "severity": severity,
                "queue_depth": queue_depth,
                "available_doctors": len(available),
                "total_doctors": total_docs,
                "estimated_clear_time": round(avg_wait, 1),
                "reason": f"{queue_depth} patients waiting with {len(available)} available doctors "
                          f"(ratio: {ratio:.1f}:1). Est. clear time: {avg_wait:.0f} min.",
            })

        return sorted(bottlenecks, key=lambda x: {"critical": 3, "high": 2, "medium": 1}[x["severity"]], reverse=True)
