#!/usr/bin/env python3
"""
Fix database schema for proper SQLAlchemy relationships
Run this script to recreate database with correct relationships
"""

import os
import sys
from app import app
from models import db

def fix_database():
    """Recreate database with proper relationships"""
    with app.app_context():
        print("Dropping all tables...")
        db.drop_all()
        
        print("Creating all tables with new relationships...")
        db.create_all()
        
        print("Database schema fixed successfully!")
        print("Please run 'python seed_data.py' to populate with sample data.")

if __name__ == "__main__":
    fix_database()
