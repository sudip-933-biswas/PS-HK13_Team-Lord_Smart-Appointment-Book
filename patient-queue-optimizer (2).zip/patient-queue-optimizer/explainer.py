"""
Explainable AI Module
Generates human-readable explanations for AI-driven scheduling decisions.
"""
from datetime import datetime


class ScheduleExplainer:
    """Provides transparent explanations for every optimization decision."""

    CONFIDENCE_LABELS = {
        (0.0, 0.3): ("Low", "warning"),
        (0.3, 0.6): ("Moderate", "info"),
        (0.6, 0.8): ("High", "primary"),
        (0.8, 1.0): ("Very High", "success"),
    }

    def get_confidence_label(self, confidence):
        """Return human-readable confidence label and badge class."""
        for (low, high), (label, badge) in self.CONFIDENCE_LABELS.items():
            if low <= confidence < high:
                return label, badge
        return "Very High", "success"

    def explain_wait_time(self, patient, queue_entry, department, doctors):
        """Explain why a patient has a specific estimated wait time."""
        dept_docs = [d for d in doctors if d.department_id == department.id]
        available = [d for d in dept_docs if d.status == "available"]
        busy = [d for d in dept_docs if d.status == "busy"]

        factors = []
        factors.append(f"You are at position #{queue_entry.position} in the {department.name} queue.")
        factors.append(f"Average consultation time in {department.name}: {department.avg_consultation_minutes:.0f} minutes.")
        factors.append(f"Currently {len(available)} doctor(s) available and {len(busy)} in consultation.")

        if patient.priority_score > 0.7:
            factors.append(f"Your priority score ({patient.priority_score:.2f}) is elevated, which may move you forward.")

        if queue_entry.estimated_wait_minutes > 20:
            factors.append("Wait time is above average. The system is looking for optimization opportunities.")

        return {
            "summary": f"Estimated wait: {queue_entry.estimated_wait_minutes:.0f} minutes",
            "factors": factors,
            "data": {
                "queue_position": queue_entry.position,
                "dept_avg_time": department.avg_consultation_minutes,
                "available_doctors": len(available),
                "busy_doctors": len(busy),
                "priority_score": patient.priority_score,
            },
        }

    def explain_priority_score(self, patient):
        """Explain how a patient's priority score was computed."""
        factors = []
        score_breakdown = {}

        # Base
        score_breakdown["base"] = 0.5
        factors.append("Base priority: 0.50 (all patients start equal)")

        # Emergency
        if patient.is_emergency:
            factors.append("Emergency flag: +0.45 (emergency patients get highest priority)")
            score_breakdown["emergency"] = 0.45
            return {
                "summary": f"Priority Score: {patient.priority_score:.2f} (Emergency)",
                "factors": factors,
                "breakdown": score_breakdown,
            }

        # Age
        age = patient.age or 30
        if age < 5 or age > 75:
            factors.append(f"Age factor: +0.15 (age {age} — very young/elderly patients prioritized)")
            score_breakdown["age"] = 0.15
        elif age < 12 or age > 65:
            factors.append(f"Age factor: +0.08 (age {age} — young/senior patients)")
            score_breakdown["age"] = 0.08
        else:
            factors.append(f"Age factor: +0.00 (age {age} — standard range)")
            score_breakdown["age"] = 0.0

        # Condition
        condition = (patient.condition or "routine checkup").lower()
        severity_map = {
            "routine checkup": 0.7, "follow-up": 0.6, "fever": 0.9,
            "chest pain": 1.5, "fracture": 1.3, "breathing difficulty": 1.6,
            "emergency trauma": 2.0,
        }
        severity = severity_map.get(condition, 1.0)
        condition_contrib = (severity - 1.0) * 0.2
        factors.append(f"Condition ({patient.condition}): {condition_contrib:+.2f} (severity: {severity:.1f})")
        score_breakdown["condition"] = round(condition_contrib, 2)

        # Wait time
        if patient.arrival_time:
            waited = (datetime.utcnow() - patient.arrival_time).total_seconds() / 60
            wait_contrib = min(waited * 0.005, 0.15)
            factors.append(f"Wait time ({waited:.0f} min): +{wait_contrib:.2f} (longer waits increase priority)")
            score_breakdown["wait_time"] = round(wait_contrib, 2)

        return {
            "summary": f"Priority Score: {patient.priority_score:.2f}",
            "factors": factors,
            "breakdown": score_breakdown,
        }

    def explain_recommendation(self, recommendation):
        """Add extra explanation layers to an optimization recommendation."""
        rec_type = recommendation.get("type", "")

        explanation = {
            "action": recommendation["description"],
            "reason": recommendation["reason"],
            "type_label": self._type_label(rec_type),
            "type_icon": self._type_icon(rec_type),
            "confidence": recommendation["confidence"],
            "confidence_label": self.get_confidence_label(recommendation["confidence"]),
            "impact_minutes": recommendation["impact"],
            "impact_label": self._impact_label(recommendation["impact"]),
        }

        return explanation

    def _type_label(self, action_type):
        labels = {
            "reassign": "Patient Reassignment",
            "slot_fill": "No-Show Slot Recovery",
            "priority_boost": "Emergency Priority Boost",
            "delay_mitigation": "Delay Mitigation",
        }
        return labels.get(action_type, "Optimization")

    def _type_icon(self, action_type):
        icons = {
            "reassign": "bi-arrow-left-right",
            "slot_fill": "bi-calendar-plus",
            "priority_boost": "bi-exclamation-triangle",
            "delay_mitigation": "bi-clock-history",
        }
        return icons.get(action_type, "bi-gear")

    def _impact_label(self, impact_minutes):
        if impact_minutes > 20:
            return "High Impact"
        elif impact_minutes > 10:
            return "Medium Impact"
        return "Low Impact"

    def generate_dashboard_insights(self, bottlenecks, optimization_logs):
        """Generate top-level insights for the dashboard."""
        insights = []

        if bottlenecks:
            critical = [b for b in bottlenecks if b["severity"] == "critical"]
            if critical:
                insights.append({
                    "level": "danger",
                    "icon": "bi-exclamation-octagon",
                    "message": f"{len(critical)} department(s) at critical capacity: "
                               f"{', '.join(b['department'] for b in critical)}",
                })

            high = [b for b in bottlenecks if b["severity"] == "high"]
            if high:
                insights.append({
                    "level": "warning",
                    "icon": "bi-exclamation-triangle",
                    "message": f"{len(high)} department(s) approaching bottleneck: "
                               f"{', '.join(b['department'] for b in high)}",
                })

        # Recent optimization actions
        recent_applied = [log for log in optimization_logs if log.applied]
        if recent_applied:
            total_saved = sum(log.impact_score or 0 for log in recent_applied)
            insights.append({
                "level": "success",
                "icon": "bi-check-circle",
                "message": f"{len(recent_applied)} optimizations applied today, "
                           f"saving an estimated {total_saved:.0f} minutes of wait time.",
            })

        pending = [log for log in optimization_logs if not log.applied]
        if pending:
            insights.append({
                "level": "info",
                "icon": "bi-lightbulb",
                "message": f"{len(pending)} pending optimization recommendations. "
                           f"Review them in the Optimization tab.",
            })

        if not insights:
            insights.append({
                "level": "success",
                "icon": "bi-check-circle",
                "message": "All departments running smoothly. No issues detected.",
            })

        return insights
